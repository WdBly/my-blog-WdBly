<?php
/**
 * Created by huxin.
 * User: huxin
 * Date: 2018/9/16 0016
 * Time: 下午 14:18
 */

namespace App\Http\Repository;


class BasicRepository
{

}