<?php
/**
 * Created by huxin.
 * User: huxin
 * Date: 2018/9/16 0016
 * Time: 下午 14:11
 */

namespace App\Http\Models;


use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $table  = 'articles';
    protected $guarded = [];
}