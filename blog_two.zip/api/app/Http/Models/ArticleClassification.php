<?php
/**
 * Created by huxin.
 * User: huxin
 * Date: 2018/9/16 0016
 * Time: 下午 14:14
 */

namespace App\Http\Models;


use Illuminate\Database\Eloquent\Model;

class ArticleClassification extends Model
{
    protected $table = 'articleclassification';
    protected $guarded = [];
}