<?php
/**
 * Created by huxin.
 * User: huxin
 * Date: 2018/9/16 0016
 * Time: 下午 14:45
 */

namespace App\Exceptions;


class SecondValidationException extends \Exception
{

}