<template>
    
</template>

<script>
    export default {
        name: "personal-growth"
    }
</script>

<style scoped>

</style>