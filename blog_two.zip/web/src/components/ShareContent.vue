<template>
    
</template>

<script>
    export default {
        name: "share-content"
    }
</script>

<style scoped>

</style>