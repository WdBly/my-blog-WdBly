<template>
    
</template>

<script>
    export default {
        name: "feed-back"
    }
</script>

<style scoped>

</style>